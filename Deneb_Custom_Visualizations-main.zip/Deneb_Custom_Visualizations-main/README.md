# Deneb_Custom_Visualizations
This repository contains a collection of custom visualizations built using the Vega visualization grammar within the Deneb custom visual for Power BI. Deneb enables advanced, declarative visualizations that go beyond standard Power BI visuals by leveraging the power and flexibility of Vega and Vega-Lite.
